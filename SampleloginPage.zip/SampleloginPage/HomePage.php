<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Home Page</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#fdcb6e"> 

<div id="main-wrapper" >
<center><h2>Home Page</h2>
<h2>Welcome brother
<?php
echo $_SESSION['Username'];
?>
</h2>
<img src="imgs/man2.jpg" class="ram"/>
</center>
<form class="myform" action="HomePage.php" method="POST">

<a href="Login.php"><input name="Long" type="button" id="longout_btn" value="Logout"/><br></a>
</form>
<?php
//if(isset($_POST['Long'])){
//echo'<script typr="java/script"> alert("button is clickled")</script>';
//session_destroy();
//header('location:Login.php');
//}
?>
</div>
</body>
</html>