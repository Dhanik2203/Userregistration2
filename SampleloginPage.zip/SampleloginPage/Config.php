<?php
$con=mysqli_connect("localhost","root","")or die("no connection");
mysqli_select_db($con,'Samplepage');
?>