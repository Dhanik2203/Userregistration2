<?php
require'Config.php';
?>
<DOCTYPE html>
<html>
<head>
<title>Register Page</title>
<link rel="stylesheet" href="css/style1.css">
</head>
<body style="background-color:#ff7675"> 

<div id="Wel"> 
<h1>Welcome</h1>
</div>
<div id="main" >
<center><h2>Register From</h2>
<img src="imgs/login-bg.jpg" class="ram1"/>
</center>
<form class="myform1" action="Register.php" method="POST">
<lable>Fullname</lable><br>
<input name="Fullname" type="text" class="inputvalue1" placeholder="type your full name" /><br>
<lable>Gender</lable>
<input type="radio" name="Gender"  class="Radio" value="Male" required />Male
<input type="radio" name="Gender"  class="Radio" value="Female" required />Female<br>
<lable>Qualification</lable><br>
<select class="Qualification" name="Qualification">
<option value="MCA">MCA</option>
<option value="BCA">BCA</option>
<option value="BBA">BBA</option>
<option value="MBA">MBA</option>
</select><br>
<lable>Address</lable><br>
<input name="Address" type="text" class="inputvalue1" placeholder="type your full Address name" /><br>
<lable>Username</lable><br>
<input name="Username" type="text" class="inputvalue1" placeholder="type your user name"  required /><br>
<lable>Password</lable><br>
<input name="Password" type="password" class="inputvalue1" placeholder="type your password" required /><br>
<lable> ConfirmPassword</lable><br>
<input name="cpassword" type="password" class="inputvalue1" placeholder="type your password" required /><br>
<input name="submit_btn" type="submit" id="Sign_btn" value="Sign Up"/><br>
<a href="Login.php"><input type="button" id="back_btn" value="Back"/><br> </a>
</form>
<?php
if(isset($_POST['submit_btn'])){
	//echo'<script type="text/javascript"> alert ("submit button click")</script>';
	$Fullname=$_POST['Fullname'];
	$Gender=$_POST['Gender'];
	$Qualification=$_POST['Qualification'];
	$Address=$_POST['Address'];
	$Username=$_POST['Username'];
	$Password=$_POST['Password'];
	$cpassword=$_POST['cpassword'];
	if($Password==$cpassword)
	{
		$query = "select * from user1 WHERE='$Username'";
		$query_run = mysqli_query($con,$query);
		{
			$query="insert into user1 values('$Fullname','$Gender','$Qualification','$Address','$Username','$Password')";
			$query_run = mysqli_query($con,$query);
			if($query_run)
			{
				echo'<script type="text/javascript"> alert ("Register")</script>';
			}
			else{
				echo'<script type="text/javascript"> alert ("error")</script>';
			}
			
		}
	}
	else{
		echo'<script type="text/javascript"> alert ("pasaword not match")</script>';
	}
}
?>
</div>
</body>
</html>